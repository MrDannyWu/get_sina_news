# -*- coding: utf-8 -*-


class SinaNewsPipeline(object):
    def process_item(self, item, spider):

        return item
